package listadinamica;

import java.util.ArrayList;
import java.util.Arrays;

public class ListaDinamica {
    public static void main(String[] args) {
        Metodos metodos = new Metodos();

        // 1. Anadir elementos
        metodos.add("Elemento 1");
        metodos.add("Elemento 2");
        metodos.add("Elemento 3");

        // 2. Obtener un elemento por indice
        System.out.println("Elemento en indice 1: " + metodos.get(1));

        // 3. Modificar un elemento en el indice 1
        metodos.set(1, "Elemento Modificado");
        System.out.println("Elemento en indice 1 despues de modificar: " + metodos.get(1));

        // 4. Eliminar un elemento
        metodos.remove("Elemento 3");
        System.out.print("Elemento eliminado::::::");
        metodos.mostrarLista();

        // 5. Obtener el tamano de la lista
        System.out.println("Tamano de la lista: " + metodos.size());

        // 6. Anadir una coleccion de elementos
        ArrayList<String> nuevaColeccion = new ArrayList<String>();
        
        nuevaColeccion.add("Elemento 3");
        nuevaColeccion.add("Elemento 4");
        
        
        metodos.addAll(nuevaColeccion);
        metodos.mostrarLista();

        // 7. Convertir la lista a un array
        System.out.println("Array de la lista: " + Arrays.toString(metodos.toArray()));

        // 8. Limpiar la lista
        metodos.clear();
        System.out.println("Lista despues de limpiar: ");
        metodos.mostrarLista();

        // 9. Comprobar si un elemento esta presente
        System.out.println("¿Contiene 'Elemento 1'? " + metodos.contains("Elemento 1"));

        // 10. Comprobar si la lista esta vacia
        System.out.println("¿Esta vacia la lista? " + metodos.isEmpty());

        // 11. Ordenar la lista
        metodos.add("Elemento 3");
        metodos.add("Elemento 1");
        metodos.add("Elemento 2");
        System.out.println("sin ordenar");
        metodos.mostrarLista();
        metodos.sort();
        System.out.println("Ordenados");
        metodos.mostrarLista();
    }
}
