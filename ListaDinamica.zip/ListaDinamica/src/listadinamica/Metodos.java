package listadinamica;

import java.util.ArrayList;  
import java.util.Collections;

public class Metodos {
    // Atributo de la clase que almacena la lista
    private ArrayList<String> lista;

    // Constructor de la clase
    public Metodos() {
        this.lista = new ArrayList<>();
    }

    // 1. Añadir un elemento
    public void add(String elemento) {
        this.lista.add(elemento); // Uso de 'this' para referirse al atributo de la clase
    }

    // 2. Obtener un elemento por índice
    public String get(int indice) {
        if (indice >= 0 && indice < this.lista.size()) {
            return this.lista.get(indice); // Uso de 'this' para referirse al atributo de la clase
        } else {
            return "Índice fuera de rango";
        }
    }

    // 3. Modificar un elemento en el índice dado
    public void set(int indice, String nuevoElemento) {
        if (indice >= 0 && indice < this.lista.size()) {
            this.lista.set(indice, nuevoElemento); // Uso de 'this' para referirse al atributo de la clase
        } else {
            System.out.println("Índice fuera de rango");
        }
    }

    // 4. Eliminar un elemento
    public void remove(String elemento) {
        this.lista.remove(elemento); // Uso de 'this' para referirse al atributo de la clase
    }

    // 5. Obtener el tamaño de la lista
    public int size() {
        return this.lista.size(); // Uso de 'this' para referirse al atributo de la clase
    }

    // 6. Añadir todos los elementos de una colección
    public void addAll(java.util.Collection<? extends String> c) {
        this.lista.addAll(c); // Uso de 'this' para referirse al atributo de la clase
    }

    // 7. Convertir la lista a un array
    public String[] toArray() {
        return this.lista.toArray(new String[0]); // Uso de 'this' para referirse al atributo de la clase
    }

    // 8. Limpiar la lista
    public void clear() {
        this.lista.clear(); // Uso de 'this' para referirse al atributo de la clase
    }

    // 9. Verificar si un elemento está presente
    public boolean contains(String o) {
        return this.lista.contains(o); // Uso de 'this' para referirse al atributo de la clase
    }

    // 10. Comprobar si la lista está vacía
    public boolean isEmpty() {
        return this.lista.isEmpty(); // Uso de 'this' para referirse al atributo de la clase
    }

    // 11. Ordenar la lista
    public void sort() {
        Collections.sort(this.lista); // Uso de 'this' para referirse al atributo de la clase
    }

    // Método para mostrar la lista
    public void mostrarLista() {
        System.out.println("Contenido de la lista: " + this.lista); // Uso de 'this' para referirse al atributo de la clase
    }
}
